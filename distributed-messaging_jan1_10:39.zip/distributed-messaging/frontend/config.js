const CONFIG = {
    API_BASE_URL: 'http://localhost:8000/api',
    WS_URL: 'ws://localhost:8001/ws',
    TOKEN_KEY: 'auth_token',
    REFRESH_TOKEN_KEY: 'refresh_token',
    USER_KEY: 'current_user'
};